#include "mon_tail.h"

#ifdef TAIL_SIMPLE

int tail(char *path, int nline)
{

  int fd, cpt_lines1, cpt_lines2 ;
  void *trash_can, *buffer ;

  trash_can = malloc(BUFSIZE*sizeof(char)) ;
  buffer = malloc(BUFSIZE*sizeof(char)) ;
  
  cpt_lines2 = (cpt_lines1 = 0) ;
  
  assert ((fd = open(path, O_RDONLY))!= (-1)) ;

  while (read(fd, trash_can, SSIZE_MAX)!=0)
    ++cpt_lines1 ;

  free(trash_can) ;
  
  lseek(fd, 0, SEEK_SET) ;

  while(cpt_lines2 != (cpt_lines1 - nline))
    {
      read(fd, trash_can, SSIZE_MAX) ;

      ++cpt_lines2 ;
    }

  while(read(fd, buffer, SSIZE_MAX) != 0) ;

  printf("%s\n", (char*)buffer) ;

  free(buffer) ;
  
  return EXIT_SUCCESS ;
}

#endif

#ifdef TAIL_RELATIVE

int index_tail_buffer(const char *buffer, int bufsize, int ntail, int *nlines)
{

  int index ;
  index = (-1) ;

  while (index <= bufsize)
    {
      ++index ;
    }

  *nlines = index + 1 ;
  
  return index ;
  
}

int tail_before_pos(int fd, unsigned int pos, int ntail)
{
  
}

#endif

#ifdef TAIL_EFFICACE

int tail(const char *path, int ntail)
{

}

#endif

#ifdef TAIL_UTILE

#endif
