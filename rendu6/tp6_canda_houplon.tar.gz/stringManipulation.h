#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int getNumberOfChar(char c, const char *s) ;

int getNIndex(char c, const char *s, int n) ;

int getFirstIndex(char c, const char *s) ;

char** cutString(char del, char *s) ;
