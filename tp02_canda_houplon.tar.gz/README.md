Antoine Canda
Alexandre Houplon

du : implémenté sans le suivi des liens symboliques.

Le fichier compile sans segfault.