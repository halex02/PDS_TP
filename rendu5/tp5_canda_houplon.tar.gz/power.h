#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/*
  power(n,p) : renvoie la valeur de n à la puissance p.
  CU : n, p 2 entiers positifs.
 */
int power(int n, int p) ;

/*
  power2 renvoie la puissance de 2 correspondant au paramètre positif n. 
 */ 
int power2(int p) ;

/*
  power3 renvoie la puissance de 3 correspondant au paramètre positif n. 
 */
int power3(int p) ;

/*
  power5 renvoie la puissance de 5 correspondant au paramètre positif n. 
 */
int power5(int p) ;
